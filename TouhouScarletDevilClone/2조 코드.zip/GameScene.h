#pragma once
enum GameScene
{
	IntroUi,
	mainMenu,
	DifficultyLevel,
	InStage,
	Finish
};