#include "SceneManager.h"

void SceneManager::Init()
{
}

void SceneManager::Update(float dt)
{
}

void SceneManager::Render()
{
}

void SceneManager::Release()
{
}
