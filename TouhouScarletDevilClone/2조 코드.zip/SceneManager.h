#pragma once
#include "config.h"

class SceneManager
{
private:


public:
	void Init();
	void Update(float dt);
	void Render();
	void Release();
};

