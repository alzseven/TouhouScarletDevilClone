#pragma once
enum class ItemType
{
	Point,
	Power
};

